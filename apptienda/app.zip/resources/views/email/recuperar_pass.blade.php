<!DOCTYPE html>
<html>
<head>
	<title>Recuperacion de clave</title>
</head>
<body>
	<h1>Hola, {{$nombre}} , tu clave es {{$clave}}</h1>
	<h6>Correo enviado por ERP ASOPHARMA</h6>
	<h6>Desarrollado por: <a href="mohansoft.com">MOHANSOFT © </a></h6>
		
</body>
</html>