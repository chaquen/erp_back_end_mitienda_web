<!DOCTYPE html>
<html>
<head>
	<title>Pedido generado</title>
</head>
<body>
    <h1>Hola bronca son las : {{var_dump($hora)}}</h1>
</body>
</html>
