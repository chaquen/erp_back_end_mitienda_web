<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>	<h1>Proceso terminado</h1>
		{{$mensaje}}
</body>
</html>