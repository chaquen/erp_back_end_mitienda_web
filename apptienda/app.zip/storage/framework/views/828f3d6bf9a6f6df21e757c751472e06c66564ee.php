<!DOCTYPE html>
<html>
<head>
	<title>Alerta generada</title>
</head>
<body>
	
        <h1>¡Mensaje de alerta por existencias bajas para el producto!</h1>
        <h2>Codigo:<?php echo e($datos->codigo_producto); ?></h2>
        <h2>Nombre producto:<?php echo e($datos->nombre_producto); ?></h2>
        <h2>Existencias producto:<?php echo e($datos->cantidad_existencias_unidades); ?></h2>
        <h2>Sede:<?php echo e($sede->nombre_sede); ?></h2>
        <h6>Correo enviado por ERP ASOPHARMA</h6>
	<h6>Desarrollado por: <a href="mohansoft.com">MOHANSOFT © </a></h6>
            
        
</body>
</html>
