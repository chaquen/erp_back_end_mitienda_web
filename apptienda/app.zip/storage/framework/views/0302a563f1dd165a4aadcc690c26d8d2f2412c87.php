<!DOCTYPE html>
<html>
<head>
	<title>Pedido generado</title>
</head>
<body>
	<h1>Reporte corte diario generado el dia, <?php echo e($fecha); ?></h1>
		

			<?php 
				$caja_inicial=0;
				$total_efectivo=0;
				$total_salida=0;
				$total_factura=0;
				 ?>
			<?php foreach($datos_corte as $key => $d): ?>
				
				<h2>NOMBRE SEDE: <?php echo e(strtoupper($d["sede"])); ?></h2>


				<h3>CAJA INICIAL</h3>	
				<?php if(count($d["reporte"]["dinero_caja_inicial"])>0): ?>
						<?php if($d["reporte"]["dinero_caja_inicial"][0]->total_entrada_inicial_caja==NULL): ?>
							<h4>$0 .00</h4>
							<?php 
								$caja_inicial=0;
							 ?>
						<?php else: ?>
							<h4>$ <?php echo e($d["reporte"]["dinero_caja_inicial"][0]->total_entrada_inicial_caja); ?></h4>	
							<?php 
								$caja_inicial=$d["reporte"]["dinero_caja_inicial"][0]->total_entrada_inicial_caja;
							 ?>
						<?php endif; ?>
					
					
				<?php else: ?>
					
					<h4>$0 .00</h4>
					<?php 
						$caja_inicial=0;
					 ?>
				<?php endif; ?>

				<h3>TOTAL ABONOS:</h3>
				<?php if(count($d["reporte"]["pago_de_clientes"])>0): ?>
					<?php if($d["reporte"]["pago_de_clientes"][0]->total_abonos==NULL): ?>
						<h4>$ 0 .00</h4>
						<?php 
							$total_efectivo=0;
						 ?>
					
					<?php else: ?>
						<h4>$ <?php echo e($d["reporte"]["pago_de_clientes"][0]->total_abonos); ?></h4>
						<?php 
							$total_efectivo=$d["reporte"]["pago_de_clientes"][0]->total_abonos;
						 ?>
					<?php endif; ?>
					
					
				<?php else: ?>
						
					
					<h4>$0 .00</h4>
					<?php 
						$total_efectivo=0;
					 ?>
					

				<?php endif; ?>
				<h3>TOTAL SALIDAS</h3>
				<?php if(count($d["reporte"]["salidas_dinero_caja"])>0): ?>
					
					<?php if($d["reporte"]["salidas_dinero_caja"][0]->total_salida==NULL): ?>
						<h4>$0 .00</h4>
						<?php 
							$total_salida=0;
						 ?>
					<?php else: ?>
						<h4>$ <?php echo e($d["reporte"]["salidas_dinero_caja"][0]->total_salida); ?></h4
						<?php 
							$total_salida=$d["reporte"]["salidas_dinero_caja"][0]->total_salida;
						 ?>
					<?php endif; ?>
					
					
					
				<?php else: ?>
					
					<h4>$0 .00</h4>
					<?php 
						$total_salida=0;
					 ?>
				<?php endif; ?>

				<h3>TOTAL FACTURACION</h3>

				<?php if(count($d["reporte"]["pagos_de_contado"])>0): ?>
					<?php if($d["reporte"]["pagos_de_contado"][0]->total_factura!=NULL): ?>

						<h4>$ <?php echo e($d["reporte"]["pagos_de_contado"][0]->total_factura); ?></h4>
						<?php 
							$total_factura=$d["reporte"]["pagos_de_contado"][0]->total_factura;
						 ?>
					<?php else: ?>
						<h4>$0 .00</h4>
						<?php 
							$total_factura=0;
						 ?>
					<?php endif; ?>	
				 <?php else: ?>
				 		<h4>$0 .00</h4>
				 		<?php 
							$total_factura=0;
						 ?>
				 <?php endif; ?>	

				
				<h3>TOTAL DINERO EFECTIVO:</h3>
				<?php if(count($d["reporte"]["entradas_en_efectivo"])>0): ?>	
					<?php if($d["reporte"]["entradas_en_efectivo"][0]->total_entradas_corte!=NULL): ?>
						<h4>$ <?php echo e($d["reporte"]["entradas_en_efectivo"][0]->total_entradas_corte+$caja_inicial+$total_efectivo+$total_factura-$total_efectivo); ?></h4>
					<?php else: ?>
						<h4>$0 .00</h4>	
					<?php endif; ?>	
				<?php else: ?>
					
					<h4>$0 .00</h4>
				<?php endif; ?>
				
				

				


				<h3>TOTAL VENTAS POR DEPARTAMENTO:</h3>
					<?php foreach($d["reporte"]["ventas_por_departamento"] as $vd): ?>
					<h3><?php echo e($vd->nombre_departamento); ?></h3>
					<h4>$ <?php echo e($vd->total_venta_por_departamento); ?></h4>
					<?php endforeach; ?>


			
				


				
			
				<h4>======================================================================</h4>
			<?php endforeach; ?>
			

		<h6>Reporte generado automaticamente por ERP ASOPHARMA</h6>
		<h6>Desarrollado por: <a href="mohansoft.com">MOHANSOFT © <?php echo e($anio); ?></a></h6>
		
	

        
</body>
</html>
