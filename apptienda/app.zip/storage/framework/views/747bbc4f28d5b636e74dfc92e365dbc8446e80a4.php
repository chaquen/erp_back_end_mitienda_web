<!DOCTYPE html>
<html>
<head>
	<title>Pedido generado</title>
</head>
<body>
		
        <h1>Su pedido se ha generado</h1>
        <table>
        	<tr>
        		<td>ID farmacia</td>
        		<td>Codigo venta farmacia</td>
        		<td>Nombre producto</td>
        		<td>Unidades por caja / unidades por presentacion</td>
        		<td>Cantidad solicitada</td>
        		<td>Codigo proveedor</td>
        	</tr>
        	<?php foreach($datos_pedido->datos->productos_pedido as $k =>  $p): ?>
        		<tr>
        			<td>
        				<?php echo e($p->id); ?>

        			</td>
        			<td>
        				<?php echo e($p->codigo_producto); ?>

        			</td>
        			<td> 
        				<?php echo e($p->nombre_producto); ?>

        			</td>
        			<td>
        				<?php echo e($p->unidades_por_caja); ?>

        			</td>
        			<td>
        				<?php echo e($p->cantidad_solicitada); ?>

        			</td>
        			<td>
        				<?php echo e($p->codigo_distribuidor); ?>

        			</td>
        		</tr>
        	<?php endforeach; ?>

        </table>
</body>
</html>
