<!DOCTYPE html>
<html>
<head>
	<title>Reporte generado</title>
</head>
<body>
	<h1>El reporte se ha generado</h1>
	<h2>Para descargar presione el link</h2>
	<a href="<?php echo e($url); ?>"><?php echo e($nombre_descarga); ?></a>
	<h4>Mensaje generado automaticamente</h4>
</body>
</html>