<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.0/jquery-ui.min.js"></script>-->
<script type="text/javascript" src="js/jquery-3.0.0.js"></script>
<script type="text/javascript" src="js/CrudBase.js"></script>
<script type="text/javascript" src="js/globales.js"></script>
<script type="text/javascript" src="js/funciones/formatos.js"></script>
<script type="text/javascript" src="js/funciones/formularios.js"></script>
<script type="text/javascript" src="js/funciones/peticiones_ajax.js"></script>
<script type="text/javascript" src="js/funciones/storage.js"></script>
<script type="text/javascript" src="js/funciones/utilidades.js"></script>
<script type="text/javascript" src="js/prototipos/prototipos.js"></script>
