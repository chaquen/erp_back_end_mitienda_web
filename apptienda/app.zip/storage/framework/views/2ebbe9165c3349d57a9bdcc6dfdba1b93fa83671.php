<!DOCTYPE html>
<html>
<head>
	<title>Pedido generado</title>
</head>
<body>
    <h1>Hola bronca son las : <?php echo e(var_dump($hora)); ?></h1>
</body>
</html>
